document.addEventListener("DOMContentLoaded", function() {
    const ctx = document.getElementById('bloodPressureChart').getContext('2d');
    const bloodPressureChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Oct, 2023', 'Nov, 2023', 'Dec, 2023', 'Jan, 2024', 'Feb, 2024', 'Mar, 2024'],
            datasets: [
                {
                    label: 'Systolic',
                    data: [120, 140, 160, 140, 160, 160],
                    borderColor: '#ff69b4',
                    backgroundColor: 'rgba(255, 105, 180, 0.2)',
                    fill: false,
                    tension: 0.1
                },
                {
                    label: 'Diastolic',
                    data: [80, 100, 120, 100, 80, 78],
                    borderColor: '#9370db',
                    backgroundColor: 'rgba(147, 112, 219, 0.2)',
                    fill: false,
                    tension: 0.1
                }
            ]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Months'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Blood Pressure'
                    },
                    min: 60,
                    max: 180
                }
            }
        }
    });
});
